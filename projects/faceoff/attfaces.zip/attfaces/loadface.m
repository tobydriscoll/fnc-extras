function x = loadface(subject,pose)
% Load in the face for the given subject number (integer) and the given
% pose (integer). 

filename = ['s',num2str(subject),'/',num2str(pose),'.pgm']; 
X = double( imread(filename) );  % read, convert to double precision
x = X(:);

end
